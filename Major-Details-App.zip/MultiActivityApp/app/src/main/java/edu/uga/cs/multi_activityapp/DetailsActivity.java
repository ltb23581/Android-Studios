package edu.uga.cs.multi_activityapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        // Find Views
        ImageView majorImageView = findViewById(R.id.majorImageView);
        TextView detailsTextView = findViewById(R.id.detailsTextView);
        Button backButton = findViewById(R.id.button);

        // Get data from Intent
        String major = getIntent().getStringExtra("major");
        String type = getIntent().getStringExtra("type");

        // Set image and text based on major and type
        if (major != null && type != null) {
            switch (major) {
                case "Computer Science":
                    majorImageView.setImageResource(type.equals("Overview") ?
                            R.drawable.cs : R.drawable.cs_jobs);
                    detailsTextView.setText(type.equals("Overview") ?
                            "Computer science covers the foundations of computing and programming. The curriculum includes hardware, operating systems, databases, networks, graphics, and AI." :
                            "Salary ranges for computer science professions:\n" +
                                    "- Software Developer: $70,000 - $120,000\n" +
                                    "- Data Analyst: $60,000 - $100,000\n" +
                                    "- Cybersecurity Specialist: $80,000 - $130,000");
                    break;

                case "Biology":
                    majorImageView.setImageResource(type.equals("Overview") ?
                            R.drawable.biology : R.drawable.bio_jobs);
                    detailsTextView.setText(type.equals("Overview") ?
                            "Biology is a liberal arts degree focused on the biological sciences. It prepares students for advanced degrees and professional programs and is vital for understanding issues like environmental degradation and genetic engineering." :
                            "Salary ranges for biology professions:\n" +
                                    "- Lab Technician: $40,000 - $70,000\n" +
                                    "- Environmental Consultant: $50,000 - $85,000\n" +
                                    "- Research Scientist: $60,000 - $100,000");
                    break;

                case "Chemistry":
                    majorImageView.setImageResource(type.equals("Overview") ?
                            R.drawable.chemistry : R.drawable.chem_jobs);
                    detailsTextView.setText(type.equals("Overview") ?
                            "Chemistry prepares students for careers in science-related fields including health sciences, business, or law. The curriculum includes chemistry courses and supporting classes in physical and biological sciences." :
                            "Salary ranges for chemistry professions:\n" +
                                    "- Chemist: $60,000 - $90,000\n" +
                                    "- Pharmacologist: $70,000 - $110,000\n" +
                                    "- Environmental Scientist: $55,000 - $85,000");
                    break;

                case "Physics":
                    majorImageView.setImageResource(type.equals("Overview") ?
                            R.drawable.physics : R.drawable.physics_jobs);
                    detailsTextView.setText(type.equals("Overview") ?
                            "Physics majors study classical mechanics, electromagnetism, and quantum mechanics, with additional electives in optics, thermodynamics, and biophysics." :
                            "Salary ranges for physics professions:\n" +
                                    "- Physicist: $75,000 - $120,000\n" +
                                    "- Aerospace Engineer: $70,000 - $110,000\n" +
                                    "- Data Scientist: $80,000 - $130,000");
                    break;

                case "Engineering":
                    majorImageView.setImageResource(type.equals("Overview") ?
                            R.drawable.engineering : R.drawable.engineering_jobs);
                    detailsTextView.setText(type.equals("Overview") ?
                            "Engineering provides a rigorous curriculum and research environment for integrating discoveries from multiple fields. It prepares students to solve complex, multi-disciplinary problems." :
                            "Salary ranges for engineering professions:\n" +
                                    "- Civil Engineer: $65,000 - $100,000\n" +
                                    "- Mechanical Engineer: $70,000 - $105,000\n" +
                                    "- Project Manager: $80,000 - $120,000");
                    break;

                default:
                    detailsTextView.setText("Select a major to view details.");
                    break;
            }
        } else {
            detailsTextView.setText("Select a major to view details.");
        }

        // Set up Back button to return to previous activity
        backButton.setOnClickListener(v -> finish());
    }
}



