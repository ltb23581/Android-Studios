package edu.uga.cs.billformeal;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText billAmount;
    private EditText numberOfDiners;
    private TextView totalPerPerson;
    private Button tip10;
    private Button tip15;
    private Button tip20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize the variables with the UI components
        billAmount = findViewById(R.id.bill_amount);
        numberOfDiners = findViewById(R.id.number_of_diners);
        totalPerPerson = findViewById(R.id.total_per_person);
        tip10 = findViewById(R.id.tip_10);
        tip15 = findViewById(R.id.tip_15);
        tip20 = findViewById(R.id.tip_20);

        // Initially hide the total per person TextView
        totalPerPerson.setVisibility(View.GONE);

        // Set onClickListeners for the tip buttons
        tip10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                billTotal(0.10); // 10% tip
            }
        });

        tip15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                billTotal(0.15); // 15% tip
            }
        });

        tip20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                billTotal(0.20); // 20% tip
            }
        });
    }

    private void billTotal(double tipPercentage) {
        // Retrieve the values from the EditTexts
        String billAmountStr = billAmount.getText().toString();
        String numberOfDinersStr = numberOfDiners.getText().toString();

        // Parse values to double or int
        double billAmount = 0.0;
        int numberOfDiners = 1;

        try {
            billAmount = Double.parseDouble(billAmountStr);
        } catch (NumberFormatException e) {
            // Handle the case where the bill amount is invalid (e.g., empty or non-numeric)
            billAmount = 0.0;
        }

        try {
            numberOfDiners = Integer.parseInt(numberOfDinersStr);
        } catch (NumberFormatException e) {
            // Handle the case where the number of diners is invalid (e.g., non-numeric)
            numberOfDiners = 1;
        }

        // Ensure that the number of diners is at least 1
        if (numberOfDiners < 1) {
            numberOfDiners = 1;
        }

        // Calculate the total bill including the tip
        double totalBill = billAmount * (1 + tipPercentage);

        // Calculate the amount per person
        double amountPerPerson = totalBill / numberOfDiners;

        // Round the total to 2 decimal places
        amountPerPerson = Math.round(amountPerPerson * 100.0) / 100.0;

        // Display the amount in the TextView
        totalPerPerson.setText(String.format("$%.2f", amountPerPerson));

        // Make the TextView visible after computation
        totalPerPerson.setVisibility(View.VISIBLE);
    }
}
