package edu.uga.cs.fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class MajorDetailFragment extends Fragment {

    private static final String ARG_MAJOR = "major";
    private ImageView majorImageView;
    private TextView majorTitleTextView; // Title TextView
    private TextView descriptionTextView;
    private TextView salaryRangeTextView;
    private TextView linkTextView;  // Link TextView
    private Button backButton;  // Back Button

    public static MajorDetailFragment newInstance(String major) {
        MajorDetailFragment fragment = new MajorDetailFragment();
        Bundle args = new Bundle();
        args.putString(ARG_MAJOR, major);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.activity_major_detail_fragment, container, false);

        // Initialize views
        majorTitleTextView = view.findViewById(R.id.major_title_text_view); // Initialize major title TextView
        majorImageView = view.findViewById(R.id.major_image_view);
        descriptionTextView = view.findViewById(R.id.description_text_view);
        salaryRangeTextView = view.findViewById(R.id.salary_range_text_view);
        linkTextView = view.findViewById(R.id.link_text_view);  // Link TextView
        backButton = view.findViewById(R.id.back_button);  // Back Button

        // Get the major argument
        String major = getArguments() != null ? getArguments().getString(ARG_MAJOR) : "";

        // Set content based on major
        switch (major) {
            case "Mathematics":
                majorTitleTextView.setText("Mathematics"); // Set major title
                majorImageView.setImageResource(R.drawable.math);
                descriptionTextView.setText("The Mathematics major emphasizes the development of analytical skills, problem-solving abilities, and quantitative reasoning. Students engage with various branches of mathematics, including calculus, algebra, and statistics, preparing them for careers in education, research, finance, and technology.");
                salaryRangeTextView.setText("Salary Ranges: Data Analyst: $60,000 - $80,000; Statistician: $70,000 - $100,000; Actuary: $80,000 - $120,000");
                linkTextView.setText("Learn more about Mathematics");
                linkTextView.setOnClickListener(v -> openLink("https://bulletin.uga.edu/MajorsGeneral?MajorId=113"));
                break;
            case "Computer Science":
                majorTitleTextView.setText("Computer Science"); // Set major title
                majorImageView.setImageResource(R.drawable.cs_jobs);
                descriptionTextView.setText("The Computer Science major prepares students for careers in software development, data analysis, and computer systems design. Coursework includes programming, algorithms, and software engineering, equipping graduates with the skills needed to tackle complex computational challenges.");
                salaryRangeTextView.setText("Salary Ranges: Software Developer: $80,000 - $120,000; Data Scientist: $90,000 - $130,000; Systems Analyst: $70,000 - $110,000");
                linkTextView.setText("Learn more about Computer Science");
                linkTextView.setOnClickListener(v -> openLink("https://www.cs.uga.edu/bachelor-science-computer-science"));
                break;
            case "Biology":
                majorTitleTextView.setText("Biology"); // Set major title
                majorImageView.setImageResource(R.drawable.bio_jobs);
                descriptionTextView.setText("The Biology major explores the science of life, studying organisms, ecosystems, and molecular processes. Students gain hands-on experience through labs and fieldwork, preparing them for careers in healthcare, research, and environmental conservation.");
                salaryRangeTextView.setText("Salary Ranges: Biologist: $50,000 - $80,000; Research Scientist: $60,000 - $90,000; Environmental Consultant: $55,000 - $85,000");
                linkTextView.setText("Learn more about Biology");
                linkTextView.setOnClickListener(v -> openLink("https://biosciences.uga.edu/biology-major-curriculum"));
                break;
            case "Chemistry":
                majorTitleTextView.setText("Chemistry"); // Set major title
                majorImageView.setImageResource(R.drawable.chem_jobs);
                descriptionTextView.setText("The Chemistry major investigates the properties, composition, and reactions of substances. Students learn through lab experiments and theoretical studies, preparing for careers in pharmaceuticals, environmental science, and education.");
                salaryRangeTextView.setText("Salary Ranges: Chemist: $55,000 - $85,000; Pharmaceutical Sales: $70,000 - $100,000; Quality Control Analyst: $60,000 - $90,000");
                linkTextView.setText("Learn more about Chemistry");
                linkTextView.setOnClickListener(v -> openLink("https://www.chem.uga.edu/bachelor-science-bs-chem"));
                break;
            case "Physics":
                majorTitleTextView.setText("Physics"); // Set major title
                majorImageView.setImageResource(R.drawable.physics_jobs);
                descriptionTextView.setText("The Physics major focuses on understanding the fundamental laws of nature, studying matter, energy, and the forces that govern the universe. Students develop critical thinking and problem-solving skills, preparing them for careers in research, engineering, and technology.");
                salaryRangeTextView.setText("Salary Ranges: Physicist: $70,000 - $110,000; Aerospace Engineer: $80,000 - $120,000; Research Scientist: $75,000 - $115,000");
                linkTextView.setText("Learn more about Physics");
                linkTextView.setOnClickListener(v -> openLink("https://phys.franklin.uga.edu/majors-degrees/content/physics-bs"));
                break;
            case "Engineering":
                majorTitleTextView.setText("Engineering"); // Set major title
                majorImageView.setImageResource(R.drawable.engineering_jobs);
                descriptionTextView.setText("The Engineering major encompasses various disciplines, focusing on applying mathematical and scientific principles to solve real-world problems. Students gain skills in design, analysis, and project management, preparing for careers in various engineering fields.");
                salaryRangeTextView.setText("Salary Ranges: Civil Engineer: $70,000 - $100,000; Mechanical Engineer: $75,000 - $110,000; Electrical Engineer: $80,000 - $120,000");
                linkTextView.setText("Learn more about Engineering");
                linkTextView.setOnClickListener(v -> openLink("https://engineering.uga.edu/degrees-programs/"));
                break;
        }

        // Back button functionality
        backButton.setOnClickListener(v -> requireActivity().getSupportFragmentManager().popBackStack());

        return view;
    }

    private void openLink(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
}






